# Game Assistant

Flutter Android Game Assistant with:
- Neon dark Flutter UI
- encrypted local Gemini API-key storage
- server-authoritative license/HWID verification
- 1-hour test-key endpoint
- Android overlay HUD
- foreground service
- MediaProjection screen recorder
- compass/direction pipeline
- ML Kit OCR dependency
- Flutter ↔ Kotlin MethodChannel
- GitHub Actions APK build

## Important

This repository intentionally does NOT contain a license-server secret or a hard-coded master signing key.

Before release, replace these placeholders in `lib/core/constants.dart`:

- `https://YOUR-DOMAIN.example/api/v1/license/verify`
- `https://YOUR-DOMAIN.example/api/v1/license/test-key`

The server should:
1. validate the license,
2. bind the license to the supplied device identifier,
3. enforce expiry,
4. rate-limit verification,
5. return signed/authoritative status.

### Voice communication

The native bridge contains the voice control boundary, but true 1-on-1/group internet voice chat requires a signaling/media backend (normally WebRTC + TURN). It is not safe to pretend that an APK alone provides secure group voice rooms.

### OCR

The ML Kit dependency and OCR service are included. A production screen-capture OCR pipeline should capture a frame with MediaProjection/ImageReader, run ML Kit on that frame, then translate the extracted English through your chosen translation backend.

### Recorder

Android MediaProjection requires user consent. The recorder uses H.264 and 60 FPS when the device supports the requested configuration. Actual encoder limits vary by phone.

## Run

```bash
flutter pub get
flutter analyze
flutter run
```

For release:

```bash
flutter build apk --release
```
