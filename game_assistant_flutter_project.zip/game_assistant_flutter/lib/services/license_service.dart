import 'dart:convert';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:http/http.dart' as http;
import '../core/constants.dart';
import 'secure_storage_service.dart';

class LicenseResult {
  final bool valid;
  final String message;
  final DateTime? expiresAt;

  const LicenseResult(this.valid, this.message, {this.expiresAt});
}

class LicenseService {
  final SecureStorageService storage;
  LicenseService(this.storage);

  Future<String> _hwid() async {
    final info = DeviceInfoPlugin();
    final android = await info.androidInfo;
    // This is an app-install/device fingerprint, not a hardware serial.
    // Server-side license systems should treat it as a binding identifier,
    // not as an unforgeable hardware secret.
    return '${android.brand}:${android.model}:${android.id}';
  }

  Future<LicenseResult> verify(String key) async {
    final trimmed = key.trim();
    if (trimmed.isEmpty) return const LicenseResult(false, 'Enter a license key.');

    try {
      final response = await http.post(
        Uri.parse(AppConstants.licenseVerifyUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'licenseKey': trimmed,
          'hwid': await _hwid(),
          'platform': 'android',
        }),
      );

      if (response.statusCode != 200) {
        return LicenseResult(false, 'License server unavailable (${response.statusCode}).');
      }

      final body = jsonDecode(response.body) as Map<String, dynamic>;
      final valid = body['valid'] == true;
      final expires = body['expiresAt']?.toString();
      final expiresAt = expires == null ? null : DateTime.tryParse(expires);

      if (!valid) {
        return LicenseResult(
          false,
          body['message']?.toString() ?? 'Invalid, expired, or device-locked license.',
        );
      }

      await storage.saveLicenseKey(trimmed);
      await storage.saveLicenseJson(jsonEncode(body));
      return LicenseResult(true, body['message']?.toString() ?? 'License active.', expiresAt: expiresAt);
    } catch (e) {
      return LicenseResult(false, 'Could not reach license server. Check internet connection.');
    }
  }

  Future<LicenseResult> generateTestKey() async {
    try {
      final response = await http.post(
        Uri.parse(AppConstants.testKeyUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'hwid': await _hwid(), 'platform': 'android'}),
      );
      if (response.statusCode != 200) {
        return LicenseResult(false, 'Test-key service unavailable.');
      }
      final body = jsonDecode(response.body) as Map<String, dynamic>;
      final key = body['licenseKey']?.toString();
      if (key == null || key.isEmpty) {
        return const LicenseResult(false, 'Test-key service returned no key.');
      }
      await storage.saveLicenseKey(key);
      return LicenseResult(true, '1-hour test key generated.');
    } catch (_) {
      return const LicenseResult(false, 'Could not generate a test key.');
    }
  }
}
