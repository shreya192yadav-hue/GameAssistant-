import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecureStorageService {
  static const _apiKey = 'gemini_api_key';
  static const _licenseKey = 'license_key';
  static const _licenseJson = 'license_json';

  final FlutterSecureStorage _storage = const FlutterSecureStorage(
    aOptions: AndroidOptions(
      encryptedSharedPreferences: true,
    ),
  );

  Future<void> saveGeminiKey(String value) => _storage.write(key: _apiKey, value: value.trim());
  Future<String?> readGeminiKey() => _storage.read(key: _apiKey);

  Future<void> saveLicenseKey(String value) => _storage.write(key: _licenseKey, value: value.trim());
  Future<String?> readLicenseKey() => _storage.read(key: _licenseKey);

  Future<void> saveLicenseJson(String value) => _storage.write(key: _licenseJson, value: value);
  Future<String?> readLicenseJson() => _storage.read(key: _licenseJson);

  Future<void> clearCredentials() async {
    await _storage.delete(key: _apiKey);
    await _storage.delete(key: _licenseKey);
    await _storage.delete(key: _licenseJson);
  }
}
