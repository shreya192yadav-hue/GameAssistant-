import 'dart:math';
import 'dart:async';
import 'package:sensors_plus/sensors_plus.dart';

class DirectionService {
  StreamSubscription<MagnetometerEvent>? _sub;
  final StreamController<double> _heading = StreamController.broadcast();

  Stream<double> get heading => _heading.stream;

  void start() {
    _sub ??= magnetometerEventStream().listen((e) {
      final value = (e.x.isNaN || e.y.isNaN) ? 0.0 : ((e.x.atan2(e.y) * 180 / 3.141592653589793) + 360) % 360;
      _heading.add(value);
    });
  }

  void stop() {
    _sub?.cancel();
    _sub = null;
  }

  void dispose() {
    stop();
    _heading.close();
  }
}
