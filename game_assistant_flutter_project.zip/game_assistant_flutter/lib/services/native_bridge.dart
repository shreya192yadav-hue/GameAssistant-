import 'package:flutter/services.dart';

class NativeBridge {
  static const MethodChannel _channel = MethodChannel('game_assistant/native');

  static Future<bool> startAssistant() async =>
      await _channel.invokeMethod<bool>('startAssistant') ?? false;

  static Future<bool> stopAssistant() async =>
      await _channel.invokeMethod<bool>('stopAssistant') ?? false;

  static Future<bool> requestOverlayPermission() async =>
      await _channel.invokeMethod<bool>('requestOverlayPermission') ?? false;

  static Future<bool> hasOverlayPermission() async =>
      await _channel.invokeMethod<bool>('hasOverlayPermission') ?? false;

  static Future<bool> requestRecorderPermission() async =>
      await _channel.invokeMethod<bool>('requestRecorderPermission') ?? false;

  static Future<bool> setHudFeature(String feature, bool enabled) async =>
      await _channel.invokeMethod<bool>('setHudFeature', {
        'feature': feature,
        'enabled': enabled,
      }) ?? false;

  static Future<bool> startRecorder() async =>
      await _channel.invokeMethod<bool>('startRecorder') ?? false;

  static Future<bool> stopRecorder() async =>
      await _channel.invokeMethod<bool>('stopRecorder') ?? false;

  static Future<void> startVoice() async =>
      _channel.invokeMethod('startVoice');

  static Future<void> stopVoice() async =>
      _channel.invokeMethod('stopVoice');

  static Future<String?> getLastRecordingPath() async =>
      _channel.invokeMethod<String>('getLastRecordingPath');
}
