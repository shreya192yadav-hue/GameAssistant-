import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'app.dart';
import 'controllers/assistant_controller.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Get.put(AssistantController(), permanent: true);
  runApp(const GameAssistantApp());
}
