import 'package:get/get.dart';
import '../services/gemini_service.dart';
import '../services/license_service.dart';
import '../services/native_bridge.dart';
import '../services/secure_storage_service.dart';

class AssistantController extends GetxController {
  final storage = SecureStorageService();
  late final LicenseService licenseService;
  final GeminiService gemini = GeminiService();

  final geminiKey = ''.obs;
  final licenseKey = ''.obs;
  final geminiConnected = false.obs;
  final licenseValid = false.obs;
  final licenseMessage = 'Not verified'.obs;
  final assistantRunning = false.obs;
  final overlayAllowed = false.obs;
  final busy = false.obs;

  final voiceEnabled = false.obs;
  final compassEnabled = false.obs;
  final recorderEnabled = false.obs;
  final translatorEnabled = false.obs;

  @override
  void onInit() {
    super.onInit();
    licenseService = LicenseService(storage);
    _restore();
  }

  Future<void> _restore() async {
    geminiKey.value = await storage.readGeminiKey() ?? '';
    licenseKey.value = await storage.readLicenseKey() ?? '';
    overlayAllowed.value = await NativeBridge.hasOverlayPermission();
  }

  Future<bool> saveAndValidateGemini(String value) async {
    busy.value = true;
    try {
      final ok = await gemini.validateKey(value);
      geminiConnected.value = ok;
      if (ok) await storage.saveGeminiKey(value);
      return ok;
    } finally {
      busy.value = false;
    }
  }

  Future<void> verifyLicense(String value) async {
    busy.value = true;
    try {
      final result = await licenseService.verify(value);
      licenseValid.value = result.valid;
      licenseMessage.value = result.message;
      if (result.valid) licenseKey.value = value.trim();
    } finally {
      busy.value = false;
    }
  }

  Future<void> generateTestKey() async {
    busy.value = true;
    try {
      final result = await licenseService.generateTestKey();
      licenseMessage.value = result.message;
      if (result.valid) {
        licenseValid.value = true;
        licenseKey.value = await storage.readLicenseKey() ?? '';
      }
    } finally {
      busy.value = false;
    }
  }

  Future<void> toggleAssistant(bool enabled) async {
    if (enabled) {
      if (!licenseValid.value) {
        licenseMessage.value = 'Verify a valid license first.';
        return;
      }
      if (!await NativeBridge.hasOverlayPermission()) {
        final granted = await NativeBridge.requestOverlayPermission();
        if (!granted) return;
      }
      assistantRunning.value = await NativeBridge.startAssistant();
      overlayAllowed.value = true;
    } else {
      await NativeBridge.stopAssistant();
      assistantRunning.value = false;
    }
  }

  Future<void> setFeature(String feature, bool enabled) async {
    switch (feature) {
      case 'voice':
        voiceEnabled.value = enabled;
        break;
      case 'compass':
        compassEnabled.value = enabled;
        break;
      case 'recorder':
        recorderEnabled.value = enabled;
        break;
      case 'translator':
        translatorEnabled.value = enabled;
        break;
    }
    await NativeBridge.setHudFeature(feature, enabled);
  }

  Future<void> toggleRecorder(bool enabled) async {
    if (enabled) {
      final granted = await NativeBridge.requestRecorderPermission();
      if (!granted) {
        recorderEnabled.value = false;
        return;
      }
      final started = await NativeBridge.startRecorder();
      recorderEnabled.value = started;
    } else {
      await NativeBridge.stopRecorder();
      recorderEnabled.value = false;
    }
    await NativeBridge.setHudFeature('recorder', recorderEnabled.value);
  }
}
