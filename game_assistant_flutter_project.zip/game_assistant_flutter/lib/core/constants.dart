class AppConstants {
  // Replace these with your HTTPS production endpoints.
  // Do NOT put private server secrets in this app.
  static const licenseVerifyUrl =
      'https://YOUR-DOMAIN.example/api/v1/license/verify';
  static const testKeyUrl =
      'https://YOUR-DOMAIN.example/api/v1/license/test-key';

  // Gemini REST endpoint. The user API key is stored locally in encrypted storage.
  static const geminiGenerateUrl =
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';

  static const appName = 'Game Assistant';
}
