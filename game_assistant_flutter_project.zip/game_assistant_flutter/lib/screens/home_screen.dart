import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/assistant_controller.dart';
import '../core/theme.dart';
import 'settings_screen.dart';
import '../services/native_bridge.dart';

class HomeScreen extends GetView<AssistantController> {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('GAME ASSISTANT'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Get.to(() => const SettingsScreen()),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Obx(() => _StatusCard(
              title: 'GEMINI BRAIN',
              status: controller.geminiConnected.value ? 'CONNECTED' : 'NOT CONNECTED',
              ok: controller.geminiConnected.value,
            )),
            const SizedBox(height: 12),
            Obx(() => _StatusCard(
              title: 'MASTER LICENSE',
              status: controller.licenseValid.value ? 'VALID' : controller.licenseMessage.value,
              ok: controller.licenseValid.value,
            )),
            const SizedBox(height: 18),
            Obx(() => Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    const Icon(Icons.gamepad_rounded, size: 58, color: neonGreen),
                    const SizedBox(height: 12),
                    Text(
                      controller.assistantRunning.value ? 'ASSISTANT ACTIVE' : 'ASSISTANT OFF',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: FilledButton.icon(
                        onPressed: controller.busy.value
                            ? null
                            : () => controller.toggleAssistant(!controller.assistantRunning.value),
                        icon: Icon(controller.assistantRunning.value ? Icons.stop : Icons.play_arrow),
                        label: Text(controller.assistantRunning.value ? 'STOP ASSISTANT' : 'START ASSISTANT'),
                      ),
                    ),
                  ],
                ),
              ),
            )),
            const SizedBox(height: 16),
            const Text('FLOATING HUD', style: TextStyle(fontWeight: FontWeight.bold, color: neonGreen)),
            const SizedBox(height: 8),
            Obx(() => Column(
              children: [
                _FeatureTile(
                  icon: Icons.mic,
                  title: 'Voice Communication',
                  subtitle: '1-on-1 / group voice transport',
                  value: controller.voiceEnabled.value,
                  onChanged: (v) => controller.setFeature('voice', v),
                ),
                _FeatureTile(
                  icon: Icons.explore,
                  title: '360° Direction Guide',
                  subtitle: 'Compass heading overlay',
                  value: controller.compassEnabled.value,
                  onChanged: (v) => controller.setFeature('compass', v),
                ),
                _FeatureTile(
                  icon: Icons.videocam,
                  title: 'High-FPS Screen Recorder',
                  subtitle: 'Android MediaProjection',
                  value: controller.recorderEnabled.value,
                  onChanged: controller.toggleRecorder,
                ),
                _FeatureTile(
                  icon: Icons.translate,
                  title: 'English → Nepali OCR',
                  subtitle: 'Image/screenshot OCR pipeline',
                  value: controller.translatorEnabled.value,
                  onChanged: (v) => controller.setFeature('translator', v),
                ),
              ],
            )),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: () async {
                final ok = await NativeBridge.hasOverlayPermission();
                Get.snackbar('Overlay', ok ? 'Permission granted' : 'Permission required');
              },
              icon: const Icon(Icons.layers),
              label: const Text('CHECK HUD PERMISSION'),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusCard extends StatelessWidget {
  final String title, status;
  final bool ok;
  const _StatusCard({required this.title, required this.status, required this.ok});

  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: Icon(ok ? Icons.check_circle : Icons.error_outline, color: ok ? neonGreen : Colors.orange),
      title: Text(title),
      subtitle: Text(status, maxLines: 2, overflow: TextOverflow.ellipsis),
    ),
  );
}

class _FeatureTile extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  const _FeatureTile({required this.icon, required this.title, required this.subtitle, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) => Card(
    child: SwitchListTile(
      secondary: Icon(icon, color: neonGreen),
      title: Text(title),
      subtitle: Text(subtitle),
      value: value,
      onChanged: onChanged,
    ),
  );
}
