import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/assistant_controller.dart';
import '../core/theme.dart';

class SettingsScreen extends GetView<AssistantController> {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final gemini = TextEditingController(text: controller.geminiKey.value);
    final license = TextEditingController(text: controller.licenseKey.value);

    return Scaffold(
      appBar: AppBar(title: const Text('SETTINGS')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('GEMINI API KEY', style: TextStyle(color: neonGreen, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          TextField(
            controller: gemini,
            obscureText: true,
            autocorrect: false,
            enableSuggestions: false,
            decoration: const InputDecoration(
              hintText: 'Paste Gemini API key',
              prefixIcon: Icon(Icons.key),
            ),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: () async {
              final ok = await controller.saveAndValidateGemini(gemini.text);
              Get.snackbar('Gemini', ok ? 'API key validated and securely stored.' : 'API key validation failed.');
            },
            icon: const Icon(Icons.verified),
            label: const Text('VALIDATE & SAVE'),
          ),
          const SizedBox(height: 28),
          const Text('MASTER LICENSE KEY', style: TextStyle(color: neonGreen, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          TextField(
            controller: license,
            obscureText: true,
            decoration: const InputDecoration(
              hintText: 'Paste license key',
              prefixIcon: Icon(Icons.lock),
            ),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: () => controller.verifyLicense(license.text),
            icon: const Icon(Icons.security),
            label: const Text('VERIFY LICENSE'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: controller.generateTestKey,
            icon: const Icon(Icons.timer),
            label: const Text('GENERATE 1-HOUR TEST KEY'),
          ),
          const SizedBox(height: 12),
          Obx(() => Text(
            controller.licenseMessage.value,
            style: TextStyle(color: controller.licenseValid.value ? neonGreen : Colors.orange),
          )),
          const SizedBox(height: 28),
          Card(
            child: const Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Security note: license validity and one-device locking must be enforced by your HTTPS server. '
                'The APK must never contain the server signing secret or a local “master key” that can mint licenses.',
              ),
            ),
          ),
        ],
      ),
    );
  }
}
