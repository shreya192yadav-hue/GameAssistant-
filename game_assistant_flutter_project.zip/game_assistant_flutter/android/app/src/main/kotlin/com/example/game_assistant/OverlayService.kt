package com.example.game_assistant

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    companion object {
        const val ACTION_FEATURE = "FEATURE"
        private var instance: OverlayService? = null

        fun start(context: Context) {
            if (!Settings.canDrawOverlays(context)) return
            val i = Intent(context, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, OverlayService::class.java))
        }

        fun setStatus(context: Context, status: String) {
            instance?.status?.text = status
        }
    }

    private var windowManager: WindowManager? = null
    private var root: LinearLayout? = null
    private var status: TextView? = null
    private val featureViews = mutableMapOf<String, TextView>()

    override fun onCreate() {
        super.onCreate()
        instance = this
        showOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_FEATURE) {
            val feature = intent.getStringExtra("feature") ?: return START_STICKY
            val enabled = intent.getBooleanExtra("enabled", false)
            featureViews[feature]?.text = "${label(feature)}  ${if (enabled) "ON" else "OFF"}"
        }
        return START_STICKY
    }

    private fun label(feature: String): String = when (feature) {
        "voice" -> "🎙 Voice"
        "compass" -> "🧭 Compass"
        "recorder" -> "🎥 Recorder"
        "translator" -> "🌐 Translator"
        else -> feature
    }

    private fun showOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 14, 22, 14)
            setBackgroundColor(Color.argb(220, 20, 20, 20))
        }

        val title = TextView(this).apply {
            text = "GAME ASSISTANT"
            textSize = 13f
            setTextColor(Color.rgb(0, 255, 102))
        }
        root!!.addView(title)

        status = TextView(this).apply {
            text = "HUD ●"
            textSize = 11f
            setTextColor(Color.WHITE)
        }
        root!!.addView(status)

        listOf("voice", "compass", "recorder", "translator").forEach {
            val tv = TextView(this).apply {
                text = "${label(it)}  OFF"
                textSize = 11f
                setTextColor(Color.WHITE)
                setPadding(0, 5, 0, 5)
            }
            featureViews[it] = tv
            root!!.addView(tv)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 20
        params.y = 160

        root!!.setOnTouchListener(DragTouchListener(params))
        windowManager!!.addView(root, params)
    }

    private inner class DragTouchListener(private val params: WindowManager.LayoutParams) : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    windowManager?.updateViewLayout(root, params)
                    return true
                }
            }
            return false
        }
    }

    override fun onDestroy() {
        try { windowManager?.removeView(root) } catch (_: Exception) {}
        instance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
