import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/assistant_controller.dart';
import '../core/theme.dart';

class SettingsScreen extends GetView<AssistantController> {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final gemini = TextEditingController(text: controller.geminiKey.value);

    return Scaffold(
      appBar: AppBar(title: const Text('SETTINGS')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('GEMINI API KEY', style: TextStyle(color: neonGreen, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          TextField(
            controller: gemini,
            obscureText: true,
            autocorrect: false,
            enableSuggestions: false,
            decoration: const InputDecoration(
              hintText: 'Paste Gemini API key',
              prefixIcon: Icon(Icons.key),
            ),
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: () async {
              final ok = await controller.saveAndValidateGemini(gemini.text);
              Get.snackbar('Gemini', ok ? 'API key validated and securely stored.' : 'API key validation failed.');
            },
            icon: const Icon(Icons.verified),
            label: const Text('VALIDATE & SAVE'),
          ),
          const SizedBox(height: 28),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('APP FEATURES', style: TextStyle(color: neonGreen, fontWeight: FontWeight.bold)),
                  SizedBox(height: 10),
                  Text('• Gemini AI brain
• Floating game HUD
• Voice-ready controls
• 360° direction/compass
• High-FPS screen recording
• English → Nepali OCR pipeline
• Flutter ↔ Kotlin native bridge
• Foreground service'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'No license system is included. The app can start directly after the required Android permissions are granted.',
            style: TextStyle(color: Colors.white70),
          ),
        ],
      ),
    );
  }
}
