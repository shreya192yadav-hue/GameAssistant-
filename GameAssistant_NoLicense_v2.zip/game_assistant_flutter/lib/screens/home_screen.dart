import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/assistant_controller.dart';
import '../core/theme.dart';
import 'settings_screen.dart';
import '../services/native_bridge.dart';

class HomeScreen extends GetView<AssistantController> {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final command = TextEditingController();
    return Scaffold(
      appBar: AppBar(
        title: const Text('GAME ASSISTANT'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Get.to(() => const SettingsScreen()),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Obx(() => _StatusCard(
              title: 'GEMINI BRAIN',
              status: controller.geminiConnected.value ? 'CONNECTED' : (controller.geminiKey.value.isEmpty ? 'ADD API KEY IN SETTINGS' : 'READY'),
              ok: controller.geminiConnected.value,
            )),
            const SizedBox(height: 12),
            Obx(() => Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    const Icon(Icons.gamepad_rounded, size: 58, color: neonGreen),
                    const SizedBox(height: 12),
                    Text(
                      controller.assistantRunning.value ? 'ASSISTANT ACTIVE' : 'ASSISTANT OFF',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: FilledButton.icon(
                        onPressed: controller.busy.value
                            ? null
                            : () => controller.toggleAssistant(!controller.assistantRunning.value),
                        icon: Icon(controller.assistantRunning.value ? Icons.stop : Icons.play_arrow),
                        label: Text(controller.assistantRunning.value ? 'STOP ASSISTANT' : 'START ASSISTANT'),
                      ),
                    ),
                  ],
                ),
              ),
            )),
            const SizedBox(height: 16),
            const Text('ASK GEMINI', style: TextStyle(fontWeight: FontWeight.bold, color: neonGreen)),
            const SizedBox(height: 8),
            TextField(
              controller: command,
              minLines: 2,
              maxLines: 4,
              decoration: const InputDecoration(
                hintText: 'Ask the assistant anything...',
                prefixIcon: Icon(Icons.chat_bubble_outline),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: controller.busy.value ? null : () => controller.askGemini(command.text),
                    icon: const Icon(Icons.send),
                    label: const Text('ASK'),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(
                  tooltip: 'Speak answer',
                  onPressed: () {
                    final text = controller.answer.value;
                    if (text.isNotEmpty) NativeBridge.speak(text);
                  },
                  icon: const Icon(Icons.volume_up),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Obx(() => controller.answer.value.isEmpty
                ? const SizedBox.shrink()
                : Card(child: Padding(padding: const EdgeInsets.all(14), child: Text(controller.answer.value)))),
            const SizedBox(height: 16),
            const Text('FLOATING HUD', style: TextStyle(fontWeight: FontWeight.bold, color: neonGreen)),
            const SizedBox(height: 8),
            Obx(() => Column(
              children: [
                _FeatureTile(
                  icon: Icons.mic,
                  title: 'Voice Communication',
                  subtitle: 'Voice-ready HUD control',
                  value: controller.voiceEnabled.value,
                  onChanged: (v) => controller.setFeature('voice', v),
                ),
                _FeatureTile(
                  icon: Icons.explore,
                  title: '360° Direction Guide',
                  subtitle: 'Compass heading overlay',
                  value: controller.compassEnabled.value,
                  onChanged: (v) => controller.setFeature('compass', v),
                ),
                _FeatureTile(
                  icon: Icons.videocam,
                  title: 'High-FPS Screen Recorder',
                  subtitle: 'Android MediaProjection',
                  value: controller.recorderEnabled.value,
                  onChanged: controller.toggleRecorder,
                ),
                _FeatureTile(
                  icon: Icons.translate,
                  title: 'English → Nepali OCR',
                  subtitle: 'OCR pipeline ready',
                  value: controller.translatorEnabled.value,
                  onChanged: (v) => controller.setFeature('translator', v),
                ),
              ],
            )),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: () async {
                final ok = await NativeBridge.hasOverlayPermission();
                Get.snackbar('Overlay', ok ? 'Permission granted' : 'Permission required');
              },
              icon: const Icon(Icons.layers),
              label: const Text('CHECK HUD PERMISSION'),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusCard extends StatelessWidget {
  final String title, status;
  final bool ok;
  const _StatusCard({required this.title, required this.status, required this.ok});

  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: Icon(ok ? Icons.check_circle : Icons.error_outline, color: ok ? neonGreen : Colors.orange),
      title: Text(title),
      subtitle: Text(status, maxLines: 2, overflow: TextOverflow.ellipsis),
    ),
  );
}

class _FeatureTile extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  const _FeatureTile({required this.icon, required this.title, required this.subtitle, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) => Card(
    child: SwitchListTile(
      secondary: Icon(icon, color: neonGreen),
      title: Text(title),
      subtitle: Text(subtitle),
      value: value,
      onChanged: onChanged,
    ),
  );
}
