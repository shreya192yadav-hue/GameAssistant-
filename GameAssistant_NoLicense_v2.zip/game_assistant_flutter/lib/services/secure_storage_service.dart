import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecureStorageService {
  static const _apiKey = 'gemini_api_key';

  final FlutterSecureStorage _storage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  Future<void> saveGeminiKey(String value) =>
      _storage.write(key: _apiKey, value: value.trim());

  Future<String?> readGeminiKey() => _storage.read(key: _apiKey);
}
