import 'package:get/get.dart';
import '../services/gemini_service.dart';
import '../services/native_bridge.dart';
import '../services/secure_storage_service.dart';

class AssistantController extends GetxController {
  final storage = SecureStorageService();
  final GeminiService gemini = GeminiService();

  final geminiKey = ''.obs;
  final geminiConnected = false.obs;
  final assistantRunning = false.obs;
  final overlayAllowed = false.obs;
  final busy = false.obs;

  final voiceEnabled = false.obs;
  final compassEnabled = false.obs;
  final recorderEnabled = false.obs;
  final translatorEnabled = false.obs;

  final answer = ''.obs;
  final heading = 0.0.obs;

  @override
  void onInit() {
    super.onInit();
    _restore();
  }

  Future<void> _restore() async {
    geminiKey.value = await storage.readGeminiKey() ?? '';
    overlayAllowed.value = await NativeBridge.hasOverlayPermission();
  }

  Future<bool> saveAndValidateGemini(String value) async {
    busy.value = true;
    try {
      final ok = await gemini.validateKey(value);
      geminiConnected.value = ok;
      if (ok) {
        geminiKey.value = value.trim();
        await storage.saveGeminiKey(value);
      }
      return ok;
    } finally {
      busy.value = false;
    }
  }

  Future<void> askGemini(String prompt) async {
    final key = geminiKey.value.trim();
    if (key.isEmpty || prompt.trim().isEmpty) {
      answer.value = 'Gemini key and a command are required.';
      return;
    }
    busy.value = true;
    try {
      answer.value = await gemini.ask(key, prompt.trim());
    } catch (e) {
      answer.value = 'Gemini error: $e';
    } finally {
      busy.value = false;
    }
  }

  Future<void> toggleAssistant(bool enabled) async {
    if (enabled) {
      if (!await NativeBridge.hasOverlayPermission()) {
        final granted = await NativeBridge.requestOverlayPermission();
        if (!granted) return;
      }
      assistantRunning.value = await NativeBridge.startAssistant();
      overlayAllowed.value = true;
    } else {
      await NativeBridge.stopAssistant();
      assistantRunning.value = false;
    }
  }

  Future<void> setFeature(String feature, bool enabled) async {
    switch (feature) {
      case 'voice':
        voiceEnabled.value = enabled;
        break;
      case 'compass':
        compassEnabled.value = enabled;
        break;
      case 'translator':
        translatorEnabled.value = enabled;
        break;
    }
    await NativeBridge.setHudFeature(feature, enabled);
  }

  Future<void> toggleRecorder(bool enabled) async {
    if (enabled) {
      final granted = await NativeBridge.requestRecorderPermission();
      if (!granted) {
        recorderEnabled.value = false;
        return;
      }
      final started = await NativeBridge.startRecorder();
      recorderEnabled.value = started;
    } else {
      await NativeBridge.stopRecorder();
      recorderEnabled.value = false;
    }
    await NativeBridge.setHudFeature('recorder', recorderEnabled.value);
  }
}
