# Game Assistant — No License Edition

Mobile-first Flutter Android game assistant scaffold.

## Included
- Gemini AI brain with secure API-key storage
- Floating HUD / overlay permission flow
- Foreground assistant service
- 360° compass/direction sensor service
- High-FPS MediaProjection recorder path
- English → Nepali OCR pipeline (ML Kit service)
- Flutter ↔ Kotlin MethodChannel bridge
- Native Android text-to-speech for Gemini replies
- Dark neon-green UI
- GitHub Actions APK build

## License system
The license/master-key system has been completely removed. There is no license key, license server, device lock, or license gate in this edition.

## GitHub upload
This ZIP is repository-ready. Extract the ZIP first, then upload the **contents** to the root of a GitHub repository. The `.github/workflows/android.yml` file must be at the repository root.

After the files are in GitHub:
1. Open **Actions**.
2. Select **Game Assistant Android Build**.
3. Run the workflow, or push a commit to `main`.
4. When it succeeds, open the workflow run and download **Game-Assistant-APK** from Artifacts.

## Important Android permissions
The first start may ask for overlay and screen-capture permissions. These are Android security permissions and are not license checks.
